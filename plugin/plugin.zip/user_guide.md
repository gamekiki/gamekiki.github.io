---
title: Plugin - KIKI Widget
---

# KIKI Widget
---

KIKI Widget 사용자 가이드입니다.

- 게임키키#을 사용하기 위해서는 아래와 같은 순서로 코딩 작업을 해 주셔야 합니다.
    1. [위젯 코드 추가](#위젯-코드-추가)
    1. [사용자 로그인 정보 연동](#로그인연동)
    1. [사용자 로그아웃 연동](#로그아웃-연동)

## 위젯 코드 추가
---

### 먼저 앱을 등록합니다.

1. [게임키키#](http://www.gamekiki.com) 사이트에서 새로운 앱을 생성합니다. 
    * 앱 만들기 <http://www.gamekiki.com/front/myapp_write.php>
1. 생성된 앱의 `appId(Application ID)` 와 `appSecret(Application Secretkey)`을 메모합니다.
    - <https://www.gamekiki.com/cms/start.php>
    > ![](http://gamekiki.com/metaadmin/assets/data/manual/section_1_1.png)
1. 찬스게임 사용을 원하시는 경우에는 찬스게임 등록 페이지를 참조하시기 바랍니다. 
    - 찬스게임 등록 <http://www.gamekiki.com/cms/chancegame.php>

### 다음으로 위젯을 실행시킬 페이지에 라이브러리를 추가합니다.

1. 위젯을 실행시킬 페이지에 게임키키 위젯 라이브러리(`kwidget.js`)를 추가합니다.
```javascript
<script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
```

1. 로그인페이지를 지정합니다.
    - 로그인이 되어있다면 위젯 클릭 시 위젯이 정상적으로 작동하게 됩니다.
    - 로그인이 되어있지 않다면 로그인 후 진행해주세요 라는 Alert 표시됩니다.
    - 로그인이 되어있지 않다면 Alert 표시 후 아래에 지정한 페이지로 이동하게 됩니다.
```javascript
kshopMds.loginPage = "./login.html";
```

1. 위젯 실행 및 AppID 설정합니다
    - 위젯을 실행하기 위해 init 함수를 호출하여 줍니다.
    - [게임키키#](http://www.gamekiki.com) 사이트에서 등록된 AppId를 지정하여 줍니다.
```javascript
kshopMds.init({
    appId : "app_NWMUorVo00000" 
}); 
```

1. 실제 웹페이지에서 설정하는 예는 아래와 같습니다.
```html
<html>
    <head>
    <meta charset="UTF-8"></meta>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
    <script>
        // 사용자 미로그인 시 로그인 redirect 페이지 (필수)
        // 사용자의 로그인 페이지로 변경해야함
        kshopMds.loginPage = "./login.html";

        // redirect된 로그인 페이지에서 설정한 유저의 로그인 쿠키를 체크합니다.
        // 사이트에서 사용자가 로그인 했을 시 true, 로그인 정보가 없다면 false로 설정하시면 됩니다
        var loginCookie = true; 
        window.addEventListener("DOMContentLoaded", function(){
            if(loginCookie){
                // 자동 로그인
                kshopMds.init({
                  appId : 'app_QwcCtWbI00000', // appId (필수)
                });
            }else{
                // 클릭 시 로그인 페이지로 이동
                kshopMds.init({
                  appId : 'app_QwcCtWbI00000',
                  autoLogin : "N"
                });
            }
        },false);
    </script>
    </head>
    <body>
    </body>
</html>
```


## 로그인연동
---

- 게임키키 위젯은 사용자의 ID별로 발급된 토큰을 기반으로 동작합니다. 
- 토큰 발급은 [`REST API`](#restAPI)를 직접 호출하거나 개발환경 별로 제공하는 모듈을 사용하여 발급 할 수 있습니다.
- 위젯에서는 cookie에 저장된 토큰을 확인하게 되는데 cookie에 저장하는 방식은 아래 두가지 방법으로 할 수 있습니다.
    1. 키키위젯 라이브러리에서 제공하는 [`kshopMds.saveUserInfo` 함수 사용](#saveUserInfo)
    1. 토큰 값을 안내된 형식으로 [직접 `cookie`에 저장](#direct)
- 위젯에서 로그인 여부(cookie에 저장된 토큰)를 확인 할 수 있습니다.
    * [로그인 확인](#check)

<a name="restAPI"></a>
### REST API 로그인 연동

1. [Login REST API](http://docs.gamekiki.com/openapi/user/login.html)를 참조해서 로그인 토큰 발급합니다.
1. 실제 페이지에서 사용하는 예는 아래와 같습니다.
```php
<?php
    $appId = "app_NWMUorVo00000";
    $secretKey = "3c640d9eee6cceba1e291e7ea834c6f027899aa38eb7b589134dd9fb8e9c10fd";
    $userId= "test001";    
    
    function sendTokenRequest($appId,$userId,$secretKey){
        // HTTPS : $loginAPIUrl = "https://api.gamekiki.com:4443/login?";
        $loginAPIUrl = "http://api.gamekiki.com/login?";

        $data = array(
            'appId' => $appId,
            'userId'=>$userId,
            'secretKey'=>$secretKey          
        );
        // use key 'http' even if you send the request to https://...
        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded",
                'method'  => 'POST',
                'content' => http_build_query($data)
            )
        );
        $context  = stream_context_create($options);
        $result = file_get_contents($loginAPIUrl, false, $context);
        if ($result === FALSE){
            $msg="can't call login API : ";
            echo($msg);
            exit();
        }else{
            $jsonData =json_decode($result);
            if($jsonData ->message == "succeed to login."){
                // 토큰 값 
                $token = $jsonData->token;
                echo($token);
            }else{
                $msg="login validation fail";
                ?>
                <script>alert("<?=$msg?>");</script>
                <?php
                exit();            
            }
        }
    }

    sendTokenRequest($appId,$userId,$secretKey);

?>
```

<a name="saveUserInfo"></a>
### 키키위젯에서 제공하는 함수를 사용한 쿠키 저장
```javascript
<script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
<script>
    kshopMds.saveUserInfo({
        appId : "app_NM00001",
        userId : "user0001",
        token : "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhcHBJZCI6ImFwcF9OV01Vb3.cklkIjoiUmF0bTA0MjQi"
    })
</script>
```

<a name="direct"></a>
### 직접 쿠키에 저장
1. API를 통해 발급받은 JSON 데이터에서 "token" 값을 추출합니다.
    - 받는 메세지
```javascript
{
    "message": "succeed to login.",
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.ey....."
}
```

    - 추출한 토큰값 
```javascript
"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhcHBJZCI6ImFwcF9OV01Vb3.cklkIjoiUmF0bTA0MjQi";
```


1. 추출한 토큰값을 사용자 Id, appId 정보와 함께 아래의 키값으로 브라우저의 쿠키에 저장시켜 줍니다.

key | value | description
--- | --- | ---
kiki_wg_pId | "app_NM00001" | 어플리케이션 id 
kiki_wg_uId | "user001" | 사용자의 userId 
kiki_wg_whole_tk | "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9" | 서버에서 받아온 토큰 값 

<a name="check"></a>
### 로그인 확인

- 키키위젯의 사용자 로그인 정보는 kwidget.js에 포함된 아래의 connMd 함수들을 통해 확인할 수 있습니다. 
 
> connMd 함수  

name  | description
--- | --- 
isAppId | 위젯에서 사용되고 있는 appId 존재 유무에 따라서 true, false 반환
isUser | 위젯에서 사용되고 있는 사용자 id 존재 유무에 따라서 true, false 반환
istoken | 위젯에서 사용되고 있는 로그인 토큰 존재 유무에 따라서 true, false 반환
getAppId | 현재 브라우저에 저장되어 있는 위젯의 AppId 반환, 없다면 null 반환
geUserId | 현재 브라우저에 저장되어 있는 위젯의 userId 반환, 없다면 null 반환
getToken | 현재 브라우저에 저장되어 있는 위젯의 토큰 반환, 없다면 null 반환

- 실제 페이지에서 사용하는 예는 아래와 같습니다.

```javascript
<script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
<script>
    var userId,appId,token;

    if(connMd.isUser()){
        userId = connMd.getUserId();
    }

    if(connMd.isAppId()){
        appId = connMd.getAppId();
    }

    if(connMd.istoken()){
        token = connMd.getToken();
    }
</script>
```


## 로그아웃 연동
---

- 사용자 사이트에서 로그아웃 실행 시 게임키키 위젯 로그아웃이 동일하게 실행되어야만 위젯의 기존 사용자 정보 또한 삭제됩니다. 
- 게임키키 위젯에서 로그아웃을 실행하는 방식은 아래 두가지 방법으로 가능합니다.
    1. 키키위젯 라이브러리에서 제공하는 [`kshopMds.logout` 함수 사용](#logout)
    1. 토큰 값을 안내된 형식으로 [직접 `cookie`에서 삭제](#cookie_direct)

<a name="logout"></a>
### 키키위젯에서 제공하는 함수를 사용한 로그아웃 

```javascript
<script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
<script>
    kshopMds.logout();
</script>
```

<a name="cookie_direct"></a>
### 직접 쿠키 삭제

- 로그인 시 설정했던 아래의 쿠키값들을 삭제해주시면 로그아웃이 됩니다

key | value | description
--- | --- | ---
kiki_wg_pId | "app_NM00001" | 어플리케이션 id 
kiki_wg_uId | "user001" | 사용자의 userId 
kiki_wg_whole_tk | "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9" | 서버에서 받아온 토큰 값 

