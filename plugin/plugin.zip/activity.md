---
title: Plugin - Activity
---

# Activity
---

Activity 사용 가이드입니다.

## 엑티비티 전송
---

1. 엑티비티 생성
    * 엑티비티 생성은 [엑티비티 생성](#) 페이지를 참조하시기 바랍니다.

2. 프레임워크에 따른 엑티비티 전송
    * 엑티비티 전송은 [로그인 연동](php.html#로그인연동)이 필요한 서비스입니다.
    * 사용하시는 프레임워크에 따라서 아래의 코드를 따라하시면 엑티비티가 전송됩니다.

## javascript

```javascript
kshopMds.sendAction({
    userId : userId,
    actId : actId,
    callback : function(okFlag, res){
        console.log("got callback",okFlag, res);
    }
});

```

### Required parameters 

Parameter | Example | Required | Description 
--- | --- | --- | --- 
userId | "test" | Required | 사용자의 id 
actId | "act_d5uIYquz00000" | Required | 전송하고자 하는 activity의 id
callback | function(okFlag,res){} | Optional | 엑티비티 전송이후 실행되는 callback

### Response 

Name | Value | Description
--- | ---
okFlag | boolean | 엑티비티 전송 성공 여부 
res    | object  | 엑티비티 전송이후 넘어오는 데이터 값 

## PHP
        
```php
<?php
include("kikiClass.php");
$userId="test";
$actId="act_fNLq2ugj00000";
$kiki = new kikiClass();
$actRst = $kiki->sendAction($userId,$actId);
if($actRst["prog"] == true){
    // 액션 성공
}else{
    // 액션 실패
}

?>
```

### Required parameters 

Parameter | Example | Required | Description 
--- | --- | --- | --- 
userId | "test" | Required | 사용자의 id 
actId | "act_d5uIYquz00000" | Required | 전송하고자 하는 activity의 id
callback | function(okFlag,res){} | Optional | 엑티비티 전송이후 실행되는 callback

### Response 

Name | Value | Description
--- | ---
prog | boolean | 엑티비티 전송 성공 여부 
token    | string  | 현재 토큰값 
result | string | 전송 결과 메세지
updatedToken | string | 현재토큰 업데이트 여부


## ASP
        
```asp
Dim userId, appId, appSecret,mgId,kiki,token
userId = "test"
appId = "app_L6l71RIp00000"
actId="act_D93CvkiM00000"

Set kiki = new kikiClass
token =kiki.token;
kiki.sendAction appId, userId, token,actId
```

### Required parameters 

Parameter | Example | Required | Description 
--- | --- | --- | --- 
userId | "app_L6l71RIp00000" | Required | 어플리케이션 id 
userId | "test" | Required | 사용자의 id 
token | "eyJhcHBJZCI6ImFwcF9OV01" | Required | 로그인 이후 발급된 토큰
actId | "act_d5uIYquz00000" | Required | 전송하고자 하는 activity의 id
