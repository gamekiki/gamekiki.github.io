---
title: Plugin - PHP
---

# PHP
---

PHP 사용자 가이드입니다.

## 로그인연동
---

1. 로그인을 실행시킬 페이지에 키키 라이브러리를 포함시킵니다.

```php
<?php
include("kikiClass.php");
?>
```

2. [생성된 앱](./start_php.html)을 참조해서 파라미터를 지정합니다.
    * [생성된 앱](./start_php.html)의 appId, appSecret,mgId를 참조해서 파라미터를 지정합니다.
    * 미니게임을 사용하지 않으실 경우, mgId 값은 false로 설정해주시면 됩니다.
    * 로그인연동이 될 userId도 같이 지정합니다.

```php
<?php
    include("kikiClass.php");
    $appSecret ="af7b5aba1e9fa06943ca0203d6c58e9b6*******************************";
    $mgId="MGMAI_E5X0c5f9";
    $appId="app_paNiDM1f00000";
    $userId="test";
?>
```
 
3. kikiClass 를 생성시킨 후, 로그인 함수를 호출해줍니다.
    * 로그인 함수 호출 시 mgId가 없는 경우 mgId값은 false로 지정해주시면 됩니다.
    * 로그인이 완료되면 응답값으로 prog 값을 줍니다.
    * prog 값이 true일 경우 로그인 성공 이후의 코드를, false 일경우 로그인 실패 코드를 넣어주시면 됩니다.

```php
<?php
    include("kikiClass.php");
    $appSecret ="af7b5aba1e9fa06943ca0203d6c58e9b6*******************************";
    $mgId="MGMAI_E5X0c5f9";
    $appId="app_paNiDM1f00000";
    $userId="test";
    $kiki = new kikiClass();
    $msg = $kiki->login($appId,$now_UserId,$appSecret, $mgId);
    if($msg["prog"] == false){
        // 로그인 실패
        echo("login fail : ".$msg["message"]);  
    }else{
        // 로그인 성공
        
    }
?>
```

4. 위젯을 실행하기 위해서 [시작하기](./start_php.md) 에서 설정한 페이지로 이동합니다.

```php
<?php
    include("kikiClass.php");
    $appSecret ="af7b5aba1e9fa06943ca0203d6c58e9b6*******************************";
    $mgId="MGMAI_E5X0c5f9";
    $appId="app_paNiDM1f00000";
    $userId="test";
    $kiki = new kikiClass();
    $msg = $kiki->login($appId,$now_UserId,$appSecret, $mgId);
    if($msg["prog"] == false){
        // 로그인 실패
        echo("login fail : ".$msg["message"]);  
    }else{
        // 로그인 성공
        header("Location: main.php");   
    }
?>
```

## 시작하기
---

1. 앱을 등록합니다.
    * 새로운 앱을 만듭니다. [앱 만들기](https://gamekiki.com/sub/sub01_application.php)
    * 생성된 앱의 Application id 와 Application secret 을 메모합니다.
      ![](http://gamebin.iptime.org/gamekiki/metaadmin/assets/data/manual/section_1_1.png)
    * 미니게임 사용을 원하시는 경우에는 [미니게임 등록](create_mini_game_link) 페이지를 참조하시기 바랍니다. 

2. 스크립트를 삽입합니다.
    * 위젯을 사용할 페이지에 키키 스크립트를 넣습니다.

```javascript
<html>
    <head>
        <meta charset="utf-8" />
        <script src="http://gamebin.iptime.org/kshop/kwidget/kwidget.js"></script>
        </head>
</html>
```

3. 로그인이 되어있지 않을 경우 이동될 url을 설정합니다.
    * 로그인 유무를 체크해서 로그인이 되어있지 않을 경우 이동될 로그인 url을 설정합니다.

```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script src="http://gamekiki.com/kshop/kwidget/kwidget.js"></script>
    <script>
        kshopMds.loginPage = "./login.html"; 
    </script>
</head>
</html>
```

4. 샘플 앱의 init 코드를  설정합니다.
    * [생성된 앱](#create_app_link)의 appId, 사용자의 userId 와 함께 init 코드를 설정합니다.
    * [미니게임](#create_mini_game_link)을 등록해서 사용을 원하실 경우에는 mgId를 파라미터로 주시면 됩니다.

```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script src="http://gamekiki.com/kshop/kwidget/kwidget.js"></script>
    <script>
    
        var appId="app_L6l71RIp00000";
        var mgId = "MGMAI_G5d0u045";
        
        kshopMds.loginPage = "./login.html"; 
        kshopMds.init({
         appId : appId,
         mgId : mgId,
         userId : "test01"
        });     
    </script>
</head>
</html>

```

5. 사이트 사용자의 쿠키 만료기간을 체크합니다.
    * 사이트 사용자의 쿠키 세션이 만료된 경우, 키키위젯의 세션 또한 만료시켜야 합니다. 
    * init 코드에 autoLogin 값을 'N'으로 넣으시면 키키위젯의 세션이 만료됩니다.

```php
<html>
<head>
    <meta charset="utf-8" />
    <script src="http://gamekiki.com/kshop/kwidget/kwidget.js"></script>
    <script>
        // 서버사이드 사용자 쿠키 정보
        var user_session_cookie = "<%=Response.cookies("user_login_session")%>";
        var autoLogin= (user_session_cookie)? "Y" : "N";
        
        var appId="app_L6l71RIp00000";
        var mgId = "MGMAI_G5d0u045";
        
        kshopMds.loginPage = "./login.html"; 
        kshopMds.init({
         appId : appId,
         mgId : mgId,
         userId : "shleetest01",
         autoLogin : autoLogin
        });     

    </script>
</head>
</html>
```

6. 로그인 페이지의 로그인 연동을 설정합니다.
    * [로그인 연동](php.html#로그인연동)을 참조해서 로그인 설정을 마치시면 로그인 이후 키키위젯을 정상적으로 사용하실 수 있습니다.