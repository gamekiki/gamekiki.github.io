---
title: Plugin - PHP
---

# PHP
---

PHP 사용자 가이드입니다.

- 게임키키#을 사용하기 위해서는 아래와 같은 순서로 코딩 작업을 해 주셔야 합니다.
    1. [위젯 코드 추가](#위젯-코드-추가)
    1. [사용자 로그인 정보 연동](#로그인연동)
    1. [사용자 로그아웃 연동](#로그아웃연동)
## 위젯 코드 추가
---

#### 먼저 앱을 등록합니다.

1. [게임키키#](http://www.gamekiki.com) 사이트에서 새로운 앱을 생성합니다. 
    * 앱 만들기 <http://www.gamekiki.com/front/myapp_write.php>
1. 생성된 앱의 appId(Application ID) 와 appSecret(Application Secretkey)을 메모합니다.
    - <https://www.gamekiki.com/cms/start.php>
    > ![](http://gamekiki.com/metaadmin/assets/data/manual/section_1_1.png)
1. 찬스게임 사용을 원하시는 경우에는 찬스게임 등록 페이지를 참조하시기 바랍니다. 
    - 찬스게임 등록 <http://www.gamekiki.com/front/#step1>

#### 다음으로 위젯을 실행시킬 페이지에 게임키키# 스크립트를 추가합니다.

1. 위젯을 사용할 페이지 `<head>` tag에 아래와 같이 키키 스크립트를 추가합니다.
```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script charset="utf-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
</head>
</html>
```
1. 로그인이 되어있지 않을 경우 이동될 `url`을 설정합니다.
    - 로그인 유무를 체크해서 로그인이 되어 있지 않을 경우 이동될 로그인 `url`을 설정합니다.
```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script charset="utf-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
    <script>
        kshopMds.loginPage = "./login.html";
    </script>
</head>
</html>
```
1. 샘플 앱의 init 코드를  설정합니다.
    - 생성된 앱의 appId, 사용자의 userId 와 함께 init 코드를 설정합니다.
```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script charset="utf-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
    <script>        
        kshopMds.loginPage = "./login.html"; 
        var appId="app_NWMUorVo00000";            
        kshopMds.init({
            appId : appId,
            userId : "test01"
        });     
    </script>
</head>
</html>
```
1. 로그인 url에서 로그인한 사용자의 쿠키 만료기간을 체크합니다.
    - 사이트 사용자의 쿠키 세션이 만료된 경우, 키키위젯의 세션 또한 만료시켜야 합니다. 
    - `init` 코드에 `autoLogin` 값을 'N'으로 넣으면 키키위젯의 세션이 만료됩니다.
```javascript
<html>
<head>
    <meta charset="utf-8" />
    <script charset="utf-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
    <script>
        // redirect된 로그인 페이지에서 설정한 유저의 로그인 쿠키 체크.
        // 사이트에서 사용자가 로그인 했을 시 true, 로그인 정보가 없다면 false로 설정
        var user_session_cookie = "<?=$_COOKIE['userLoginSession']?>";
        var autoLogin= (user_session_cookie)? "Y" : "N";
        
        kshopMds.loginPage = "./login.html"; 
        var appId="app_NWMUorVo00000";
        kshopMds.init({
            appId : appId,
            userId : "test01",
            autoLogin : autoLogin
        });
    </script>
</head>
</html>
```

## 로그인연동
---

1. 로그인을 실행시킬 페이지에 키키 라이브러리를 포함시킵니다.
    - `kikiClass.zip` [다운로드](http://www.gamekiki.com/data/kikiClass.zip)
    ```php
    <?php
        include("kikiClass.php");
    ?>
    ```
1. [생성된 앱](https://www.gamekiki.com/cms/start.php)정보를 참조해서 아래와 같이 파라미터를 지정합니다.
    - [생성된 앱](https://www.gamekiki.com/cms/start.php)의 `appId`, `appSecret` 값을 파라미터로 지정합니다.
    - 로그인 연동이 될 사용자 ID(userId)도 함께 지정합니다.
    ```php
    <?php
        include("kikiClass.php");

        $appId="app_NWMUorVo00000";
        $appSecret ="3c640d9eee6cceba1e291e7ea834c6**********************************";
        $userId="test00";
    ?>
    ```
1. `kikiClass`를 생성시킨 후, 로그인 함수를 호출합니다.
    - 로그인이 완료되면 응답값으로 `prog` 값을 받게 됩니다.
    - `prog` 값이 `true`일 경우 로그인 성공 이후의 코드를 `false` 일 경우 로그인 실패 코드를 넣어줍니다.
    ```php
    <?php
        include("kikiClass.php");

        $appId="app_NWMUorVo00000";
        $appSecret ="3c640d9eee6cceba1e291e7ea834c6**********************************";
        $userId="test00";

        $kiki = new kikiClass();
        $msg = $kiki->login($appId,$userId,$appSecret);
        if($msg["prog"] == false){
            // 로그인 실패
            echo("login fail : ".$msg["message"]);  
        }else{
            // 로그인 성공            
        }
    ?>
    ```
1. 위젯을 실행하기 위해서 [위젯 코드 추가](#위젯-코드-추가)를 설정한 페이지로 이동합니다.
    ```php
    <?php
        include("kikiClass.php");

        $appId="app_NWMUorVo00000";
        $appSecret ="3c640d9eee6cceba1e291e7ea834c6**********************************";
        $userId="test00";

        $kiki = new kikiClass();
        $msg = $kiki->login($appId,$userId,$appSecret);
        if($msg["prog"] == false){
            // 로그인 실패
            echo("login fail : ".$msg["message"]);  
        }else{
            // 로그인 성공
           `header("Location: main.php");`
        }
    ?>
    ```

## 로그아웃 연동


사용자 사이트에서 로그아웃 실행 시 위젯 로그아웃이 동일하게 실행되어야만 위젯의 기존 사용자 정보 또한 삭제됩니다. 
로그아웃은 아래와 같이 실행시키시면 됩니다 

### 키키위젯에서 제공하는 함수를 사용한 로그아웃 

### php 
    ```php
    <?php
        include("kikiClass.php");
          $kiki = new kikiClass();
          $kiki->logout();
    ?>
    ```

### js

```javascript
<script charset="UTF-8" src="http://gamekiki.com/kshop/kwidget/js/kwidget.js"></script>
<script>
    kshopMds.logout();
</script>
```

### 직접 쿠키 삭제

로그인 시 설정했던 쿠키들을 삭제해주시면 로그아웃이 됩니다

key | value | description
--- | --- | ---
kiki_wg_pId | "app_NM00001" | 어플리케이션 id 
kiki_wg_uId | "user001" | 사용자의 userId 
kiki_wg_whole_tk | "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9" | 서버로부터 얻은 토큰 값 


